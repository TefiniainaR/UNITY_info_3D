using System.Collections;
using UnityEngine;
using TMPro;  // For using TextMeshPro
using UnityEngine.SceneManagement;  // If you want to load another scene after dialogue

public class DialogueManager : MonoBehaviour
{
    public TextMeshProUGUI dialogueText;  // Reference to the UI TextMeshProUGUI element
    public GameObject dialogueBox;  // Reference to the DialogueBox panel (black box)
    public float typingSpeed = 0.05f;  // Speed of typing effect
    private string[] dialogueLines;  // Array of dialogue lines
    private int currentLine = 0;  // Keeps track of the current line of dialogue

    private bool isTyping = false;  // Determines if the text is currently typing
    private bool isInternalMonologue = false;  // Flag to differentiate internal monologue from spoken dialogue

    public GameObject sideDoor;  // Reference to the side door in the scene (for environmental interaction)
    public Camera mainCamera;  // Reference to the camera

    void Start()
    {
        // Define dialogue for the scene (including internal and spoken)
        dialogueLines = new string[]
        {
            "Psychologist (internal): They're here again. That's something.",
            "Psychologist (internal): No words. Just that silence I've grown used to.",
            "Psychologist : You don't need to speak if you don't want to.",
            "Psychologist : But today, I'd like to try something different.",
            "Psychologist : You said everything feels distant, like you're somewhere else. Let's go there... together.",
            "Psychologist : We're not escaping. We're exploring. One step at a time."
        };

        // Ensure the dialogue box is visible and ready to display text
        dialogueBox.SetActive(true);
        StartCoroutine(DisplayDialogue());  // Start the dialogue sequence when the scene begins
    }

    void Update()
    {
        // Wait for the player to press Space to continue the conversation
        if (!isTyping && Input.GetKeyDown(KeyCode.Space))
        {
            // Move to the next line of dialogue
            currentLine++;
            if (currentLine < dialogueLines.Length)
            {
                StartCoroutine(DisplayDialogue());  // Display next line of dialogue
            }
            else
            {
                // End of dialogue, hide the dialogue box
                dialogueText.text = "";
                dialogueBox.SetActive(false);

                // You can trigger environmental actions (like opening the door or changing the camera) after the dialogue finishes
                if (sideDoor != null)
                {
                    StartCoroutine(OpenSideDoor());
                }
            }
        }
    }

    // Coroutine to display dialogue with typing effect
    IEnumerator DisplayDialogue()
    {
        isTyping = true;
        dialogueText.text = "";  // Clear any previous dialogue

        string line = dialogueLines[currentLine];
        
        // Check if the current line is an internal monologue or spoken aloud
        if (line.Contains("internal monologue"))
        {
            isInternalMonologue = true;
            dialogueText.color = Color.gray;  // Display internal monologue in gray (optional)
        }
        else
        {
            isInternalMonologue = false;
            dialogueText.color = Color.white;  // Default white for spoken dialogue
        }

        // Show each character one by one (typing effect)
        foreach (char letter in line.ToCharArray())
        {
            dialogueText.text += letter;
            yield return new WaitForSeconds(typingSpeed);  // Wait for the next character
        }

        isTyping = false;  // Typing finished, wait for player input to continue
    }

    // Coroutine for opening the side door with a small camera movement after the last dialogue
    IEnumerator OpenSideDoor()
    {
        // Change the camera to focus on the side door slowly (camera movement)
        float time = 0f;
        Vector3 startPos = mainCamera.transform.position;
        Vector3 endPos = sideDoor.transform.position + new Vector3(0, 0, -5f);  // Adjust to get a good angle

        while (time < 1f)
        {
            mainCamera.transform.position = Vector3.Lerp(startPos, endPos, time);
            time += Time.deltaTime / 2f;  // Duration of camera movement (2 seconds)
            yield return null;
        }

        // Open the door (trigger animation or event)
        // Assuming you have an Animator component on the side door
        if (sideDoor.GetComponent<Animator>())
        {
            sideDoor.GetComponent<Animator>().SetTrigger("OpenDoor");
        }

        // Optionally, load a new scene if needed
        // SceneManager.LoadScene("NextSceneName");
    }
}
