using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class WordChanger : MonoBehaviour
{
    // Liste des phrases négatives et positives en anglais
    public string[] negativePhrases = { "I am useless", "What's the point?", "No one listens to me" };
    public string[] positivePhrases = { "I can be useful", "Everything has a purpose", "I deserve to be heard" };

    private TextMeshProUGUI textMesh;
    private bool isSelected = false;

    void Start()
    {
        textMesh = GetComponent<TextMeshProUGUI>();  // Assure-toi d'attacher ce script au TextMeshPro
    }

    void OnMouseDown()
    {
        // Quand le joueur clique sur un mot, on change le texte
        if (!isSelected)
        {
            int index = System.Array.IndexOf(negativePhrases, textMesh.text);
            if (index != -1)
            {
                textMesh.text = positivePhrases[index];
                isSelected = true;
            }
        }
    }
}
