using UnityEngine;

public class MirrorPuzzleChecker : MonoBehaviour
{
    public GameObject[] mirrorPieces; // Liste des morceaux de miroir
    public Vector3[] correctPositions; // Positions correctes des morceaux

    void Update()
    {
        bool isPuzzleComplete = true;

        // Vérifier si chaque morceau est à la bonne position
        for (int i = 0; i < mirrorPieces.Length; i++)
        {
            if (Vector3.Distance(mirrorPieces[i].transform.position, correctPositions[i]) > 0.5f)
            {
                isPuzzleComplete = false;
                break;
            }
        }

        if (isPuzzleComplete)
        {
            // Le puzzle est complet, tu peux afficher le miroir complet par exemple
            Debug.Log("Puzzle done !");
        }
    }
}
