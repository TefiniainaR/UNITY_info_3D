using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallLighting : MonoBehaviour
{
    public Light sceneLight;  // Lumière à ajuster
    private int wordsChanged = 0;  // Compteur de mots modifiés

    void Start()
    {
        if (sceneLight == null)
        {
            sceneLight = FindObjectOfType<Light>();  // Trouver la lumière de la scène si elle n'est pas spécifiée
        }
    }

    public void IncreaseLight()
    {
        wordsChanged++;
        sceneLight.intensity = Mathf.Lerp(1, 3, wordsChanged / 5f);  // Augmenter la lumière progressivement
    }
}
