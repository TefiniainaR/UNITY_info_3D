﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Akane_CharacterController : MonoBehaviour
{
    private CharacterController controller;
    private Vector3 playerVelocity;
    private bool groundedPlayer;
    private float playerSpeed = 5.0f;  // Adjusted speed for better movement
    private float gravityValue = -9.81f;
    private Animator animator;
    private float rotationSpeed = 700f;  // Rotation speed to smoothly rotate towards movement direction

    // For camera-based movement, use the camera to adjust movement
    public Transform cameraTransform;

    private void Start()
    {
        animator = GetComponent<Animator>();
        controller = gameObject.GetComponent<CharacterController>();

        // Automatically assign the cameraTransform if not set
        if (cameraTransform == null)
        {
            // Try to find the camera by name
            cameraTransform = GameObject.Find("Camera").transform;  // Find the camera by its name "Camera"
            if (cameraTransform == null)
            {
                Debug.LogError("No camera found with the name 'Camera'. Please assign a camera to the cameraTransform.");
            }
        }
    }

    void Update()
    {
        // Check if the character is grounded
        groundedPlayer = controller.isGrounded;

        // Reset vertical velocity when grounded
        if (groundedPlayer && playerVelocity.y < 0)
        {
            playerVelocity.y = -2f;  // A small negative value to keep the player on the ground
        }

        // Get input from the player
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        // Create a movement vector based on input
        Vector3 move = new Vector3(horizontal, 0.0f, vertical);

        // If there is any movement, adjust the movement direction relative to the camera
        if (move != Vector3.zero)
        {
            // Get the direction relative to the camera
            Vector3 direction = cameraTransform.forward * move.z + cameraTransform.right * move.x;
            direction.y = 0;  // Keep the movement in the horizontal plane

            // Normalize direction and apply movement
            controller.Move(direction.normalized * Time.deltaTime * playerSpeed);

            // Smoothly rotate the character towards the movement direction
            Quaternion toRotation = Quaternion.LookRotation(direction);
            transform.rotation = Quaternion.RotateTowards(transform.rotation, toRotation, rotationSpeed * Time.deltaTime);

            // Set walking animation
            animator.SetBool("isWalk", true);
        }
        else
        {
            animator.SetBool("isWalk", false);
        }

        // Apply gravity if not grounded
        if (!groundedPlayer)
        {
            playerVelocity.y += gravityValue * Time.deltaTime;
        }

        // Move the character with gravity
        controller.Move(playerVelocity * Time.deltaTime);
    }
}
