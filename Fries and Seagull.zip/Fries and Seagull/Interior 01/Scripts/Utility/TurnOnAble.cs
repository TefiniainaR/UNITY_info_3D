﻿using UnityEngine;

namespace Seagull.Interior_01.Utility {
    public class TurnOnAble : MonoBehaviour {
        
    }
}