Install "Materials_URP (DoubleClickMe)" package above by double clicking it
to replace all Standard materials with URP alternatives.