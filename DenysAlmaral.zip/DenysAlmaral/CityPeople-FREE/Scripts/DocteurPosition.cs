using UnityEngine;

public class DocteurPosition : MonoBehaviour
{
    public Transform chaise;  // Référence à la chaise dans la scène
    public Vector3 offsetPosition = new Vector3(0, 1, 0);  // Ajuste la position pour que le docteur soit bien assis (hauteur, etc.)

    private void Start()
    {
        // Positionner le docteur à la chaise avec l'offset
        PositionnerAssis();
    }

    // Fonction pour positionner le docteur assis
    public void PositionnerAssis()
    {
        if (chaise != null)
        {
            // Positionner le docteur à la même position que la chaise avec un décalage sur l'axe Y pour qu'il soit assis.
            transform.position = chaise.position + offsetPosition;

            // Assurer que le docteur est orienté correctement (la même rotation que la chaise ou une valeur fixe)
            transform.rotation = Quaternion.Euler(0, chaise.rotation.eulerAngles.y, 0);  // L'axe Y pour orientation
        }
    }
}

